public interface DocumentFactory {
    Document createDocument();
}